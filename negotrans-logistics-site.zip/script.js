
document.addEventListener('DOMContentLoaded', () => {
    const app = document.getElementById('app');
    app.innerHTML = '<h1>NEGOTRANS LOGISTICS</h1><p>Site en construction. Merci de votre patience.</p>';
});
